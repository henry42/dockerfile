local config = {}

local valid_params = {'ENABLED', 'ENABLE_INTERNAL', 'API_URL', 'API_KEY', 'BOUNCING_ON_TYPE', 'MODE', 'SECRET_KEY', 'SITE_KEY', 'BAN_TEMPLATE_PATH' ,'CAPTCHA_TEMPLATE_PATH', 'REDIRECT_LOCATION', 'RET_CODE', 'CAPTCHA_RET_CODE', 'EXCLUDE_LOCATION', 'FALLBACK_REMEDIATION', 'CAPTCHA_PROVIDER', 'APPSEC_URL', 'APPSEC_FAILURE_ACTION', 'ALWAYS_SEND_TO_APPSEC', 'APPSEC_DROP_UNREADABLE_BODY', 'SSL_VERIFY', 'USE_TLS_AUTH', 'TLS_CLIENT_CERT', 'TLS_CLIENT_KEY', 'SCENARIOS_CONTAINING', 'SCENARIOS_NOT_CONTAINING'}
local valid_int_params = {'CACHE_EXPIRATION', 'CACHE_SIZE', 'REQUEST_TIMEOUT', 'UPDATE_FREQUENCY', 'CAPTCHA_EXPIRATION', 'APPSEC_CONNECT_TIMEOUT', 'APPSEC_SEND_TIMEOUT', 'APPSEC_PROCESS_TIMEOUT', 'STREAM_REQUEST_TIMEOUT'}
-- CACHE_SIZE is not used in the code, but as is was valid parameter for the configuration file, not removing it now
local valid_bouncing_on_type_values = {'ban', 'captcha', 'all'}
local valid_truefalse_values = {'false', 'true'}
local default_values = {
    ['ENABLED'] = "true",
    ['ENABLE_INTERNAL'] = "false",
    ['API_URL'] = "",
    ['REQUEST_TIMEOUT'] = 500,
    ['STREAM_REQUEST_TIMEOUT'] = 15000,
    ['BOUNCING_ON_TYPE'] = "ban",
    ['MODE'] = "stream",
    ['UPDATE_FREQUENCY'] = 10,
    ['CAPTCHA_EXPIRATION'] = 3600,
    ['REDIRECT_LOCATION'] = "",
    ['EXCLUDE_LOCATION'] = {},
    ['RET_CODE'] = 0,
    ['CAPTCHA_PROVIDER'] = "recaptcha",
    ['APPSEC_URL'] = "",
    ['APPSEC_CONNECT_TIMEOUT'] = 100,
    ['APPSEC_SEND_TIMEOUT'] = 100,
    ['APPSEC_PROCESS_TIMEOUT'] = 500,
    ['APPSEC_FAILURE_ACTION'] = "passthrough",
    ['SSL_VERIFY'] = "true",
    ['ALWAYS_SEND_TO_APPSEC'] = "false",
    ['APPSEC_DROP_UNREADABLE_BODY'] = "false",
    ['CAPTCHA_RET_CODE'] = 0,
    ['CACHE_EXPIRATION'] = 1,
    ['USE_TLS_AUTH'] = "false",
    ['TLS_CLIENT_CERT'] = "",
    ['TLS_CLIENT_KEY'] = "",
    ['SCENARIOS_CONTAINING'] = "",
    ['SCENARIOS_NOT_CONTAINING'] = "",
}


function config.file_exists(file)
    local f = io.open(file, "rb")
    if f then
        f:close()
    end
    return f ~= nil
end

local function has_value (tab, val)
    for _, value in ipairs(tab) do
        if value == val then
            return true
        end
    end

    return false
end

local function starts_with(str, start)
    return str:sub(1, #start) == start
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

--- Load configuration from file
-- called from crowdsec.lua
-- @param file string path to the configuration file
-- @param default boolean if true, load default values for missing parameters
-- @return conf table with configuration values
function config.loadConfig(file, default)
    if not config.file_exists(file) then
        return nil, "File ".. file .." doesn't exist"
    end
    local conf = {}
    for line in io.lines(file) do
        local isOk = false
        if starts_with(line, "#") then
            isOk = true
        end
        if trim(line) == "" then
            isOk = true
        end
        if not isOk then
        local sep_pos = line:find("=")
        if not sep_pos then
           ngx.log(ngx.ERR, "invalid configuration line: " .. line)
           break
        end
        local key = trim(line:sub(1, sep_pos - 1))
        local value = trim(line:sub(sep_pos + 1))
        if has_value(valid_params, key) then
            if key == "ENABLED" then
                if not has_value(valid_truefalse_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'true' instead")
                    value = "true"
                end
            elseif key == "ENABLE_INTERNAL" then
                if not has_value(valid_truefalse_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'false' instead")
                    value = "false"
                end
            elseif key == "BOUNCING_ON_TYPE" then
                if not has_value(valid_bouncing_on_type_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'ban' instead")
                    value = "ban"
                end
            elseif key == "SSL_VERIFY" then
                if not has_value(valid_truefalse_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'true' instead")
                    value = "true"
                end
            elseif key == "USE_TLS_AUTH" then
                if not has_value(valid_truefalse_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'false' instead")
                    value = "false"
                end
            elseif key == "APPSEC_DROP_UNREADABLE_BODY" then
                if not has_value(valid_truefalse_values, value) then
                    ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'false' instead")
                    value = "false"
                end
            elseif key == "MODE" then
                if not has_value({'stream', 'live'}, value) then
                ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'stream' instead")
                value = "stream"
                end
            elseif key == "FALLBACK_REMEDIATION" then
                if not has_value({'captcha', 'ban'}, value) then
                ngx.log(ngx.ERR, "unsupported value '" .. value .. "' for variable '" .. key .. "'. Using default value 'ban' instead")
                value = "ban"
                end
            end
            conf[key] = value

            if key == "EXCLUDE_LOCATION" then
                local exclude_location = {}
                if value ~= "" then
                    for match in (value..","):gmatch("(.-)"..",") do
                        table.insert(exclude_location, match)
                    end
                end
                conf[key] = exclude_location
            end


        elseif has_value(valid_int_params, key) then
            conf[key] = tonumber(value)
        else
            ngx.log(ngx.ERR, "unsupported configuration '" .. key .. "'")
        end
        end
    end
    if default then
        for k, v in pairs(default_values) do
            if conf[k] == nil then
                conf[k] = v
            end
        end
    end
    return conf, nil
end


return config
