local cjson = require "cjson"
local utils = require "plugins.crowdsec.utils"

local live = {}
live.__index = live

live.cache = ngx.shared.crowdsec_cache

--- Create a new live object
-- Create a new live object to query the live API
-- @return live: the live object

function live:new()
  return self
end

--- Live query the API to get the decision for the IP using API key authentication
-- Query the live API to get the decision for the IP in real time
-- @param ip string: the IP to query
-- @param api_url string: the URL of the LAPI
-- @param timeout number: the timeout of the request to lapi
-- @param cache_expiration number: the expiration time of the cache
-- @param api_key_header string: the authorization header to use for the lapi request
-- @param api_key string: the API key to use for the lapi request
-- @param user_agent string: the user agent to use for the lapi request
-- @param ssl_verify boolean: whether to verify the SSL certificate or not
-- @param bouncing_on_type string: the type of decision to bounce on
-- @param scenarios_containing string: comma-separated substrings; only consider decisions whose scenario contains one of them
-- @param scenarios_not_containing string: comma-separated substrings; ignore decisions whose scenario contains one of them
-- @return boolean: true if the IP is allowed, false if the IP is blocked
-- @return string: the type of the decision
-- @return string: the origin of the decision
-- @return string: the error message if any
function live:live_query_api(ip, api_url, timeout, cache_expiration, api_key_header, api_key, user_agent, ssl_verify, bouncing_on_type, scenarios_containing, scenarios_not_containing)
  local link = api_url .. "/v1/decisions?ip=" .. ip .. utils.scenario_filters(scenarios_containing, scenarios_not_containing)
  local res, err = utils.get_remediation_http_request(link, timeout, api_key_header, api_key, user_agent, ssl_verify)

  if not res then
    ngx.log(ngx.ERR, "failed to query LAPI " .. link .. ": ".. err)
    return true, nil, nil, "request failed: ".. err
  end

  return self:live_query_process(res, ip, cache_expiration, bouncing_on_type, link)
end

--- Live query the API to get the decision for the IP using mTLS authentication
-- Query the live API to get the decision for the IP in real time
-- @param ip string: the IP to query
-- @param api_url string: the URL of the LAPI
-- @param timeout number: the timeout of the request to lapi
-- @param cache_expiration number: the expiration time of the cache
-- @param user_agent string: the user agent to use for the lapi request
-- @param ssl_verify boolean: whether to verify the SSL certificate or not
-- @param ssl_client_cert string: path to the client certificate file
-- @param ssl_client_priv_key string: path to the client private key file
-- @param bouncing_on_type string: the type of decision to bounce on
-- @param scenarios_containing string: comma-separated substrings; only consider decisions whose scenario contains one of them
-- @param scenarios_not_containing string: comma-separated substrings; ignore decisions whose scenario contains one of them
-- @return boolean: true if the IP is allowed, false if the IP is blocked
-- @return string: the type of the decision
-- @return string: the origin of the decision
-- @return string: the error message if any
function live:live_query_tls(ip, api_url, timeout, cache_expiration, user_agent, ssl_verify, ssl_client_cert, ssl_client_priv_key, bouncing_on_type, scenarios_containing, scenarios_not_containing)
  local link = api_url .. "/v1/decisions?ip=" .. ip .. utils.scenario_filters(scenarios_containing, scenarios_not_containing)
  local res, err = utils.get_remediation_http_request_tls(link, timeout, user_agent, ssl_verify, ssl_client_cert, ssl_client_priv_key)

  if not res then
    ngx.log(ngx.ERR, "failed to query LAPI " .. link .. ": ".. err)
    return true, nil, nil, "request failed: ".. err
  end

  return self:live_query_process(res, ip, cache_expiration, bouncing_on_type, link)
end

--- Process the HTTP response from the CrowdSec API for live queries
-- @param res table: the HTTP response object
-- @param ip string: the IP being queried
-- @param cache_expiration number: the expiration time of the cache
-- @param bouncing_on_type string: the type of decision to bounce on
-- @param link string: the API link for error reporting
-- @return boolean: true if the IP is allowed, false if the IP is blocked
-- @return string: the type of the decision
-- @return string: the origin of the decision
-- @return string: the error message if any
function live:live_query_process(res, ip, cache_expiration, bouncing_on_type, link)
  local status = res.status
  local body = res.body
  if status~=200 then
    return true, nil, nil, "Http error " .. status .. " while talking to LAPI (" .. link .. ")"
  end

  --- TODO (after metrics merge) see if following code can be refactored
  if body == "null" then -- no result from API, no decision for this IP
    -- set ip in cache and DON'T block it
    local key,_ = utils.item_to_string(ip, "ip")
    if key == nil then
      ngx.log(ngx.WARN, "[Crowdsec] Failed to parse IP address for caching: " .. tostring(ip) .. " - skipping cache")
      return true, nil, nil, nil
    end
    local succ, err, forcible = live.cache:set("decision_cache/" .. key, "none", cache_expiration, 1)
    --
    ngx.log(ngx.DEBUG, "[CACHE] Adding '" .. key .. "' in cache for '" .. cache_expiration .. "' seconds") --debug
    if not succ then
      ngx.log(ngx.ERR, "failed to add ip '" .. ip .. "' in cache: ".. err)
    end
    if forcible then
      ngx.log(ngx.ERR, "Lua shared dict (crowdsec cache) is full, please increase dict size in config")
    end
    return true, nil, nil, nil
  end
  local decision = cjson.decode(body)[1]

  if decision.origin == "lists" and decision.scenario ~= nil then
    decision.origin = "lists:" .. decision.scenario
  end
  local cache_value = decision.type .. "/" .. decision.origin
  local key,_ = utils.item_to_string(decision.value, decision.scope)
  if key == nil then
    ngx.log(ngx.WARN, "[Crowdsec] Failed to parse decision value for caching: " .. tostring(decision.value) .. " with scope: " .. tostring(decision.scope) .. " - skipping cache")
    return true, nil, nil, nil
  end
  local succ, err, forcible = live.cache:set("decision_cache/" .. key, cache_value, cache_expiration, 0)
  ngx.log(ngx.DEBUG, "[CACHE] Adding '" .. key .. "' in cache for '" .. cache_expiration .. "' seconds with decision type'" .. decision.type .. "'with origin'" .. decision.origin ) --debug
  if not succ then
    ngx.log(ngx.ERR, "failed to add ".. decision.value .." : "..err)
  end
  if forcible then
    ngx.log(ngx.ERR, "Lua shared dict (crowdsec cache) is full, please increase dict size in config")
  end
  if bouncing_on_type == decision.type or bouncing_on_type == "all" then
    return false, decision.type, decision.origin, nil
  else
    return true, nil, nil, nil
  end
end

return live
