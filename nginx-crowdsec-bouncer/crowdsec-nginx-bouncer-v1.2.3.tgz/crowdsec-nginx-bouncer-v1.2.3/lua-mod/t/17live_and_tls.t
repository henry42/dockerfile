use Test::Nginx::Socket 'no_plan';

run_tests();

__DATA__

=== TEST 17: TLS Auth mode test

--- main_config
load_module /usr/share/nginx/modules/ndk_http_module.so;
load_module /usr/share/nginx/modules/ngx_http_lua_module.so;

--- http_config

lua_package_path './lib/?.lua;;';
lua_shared_dict crowdsec_cache 50m;
lua_ssl_trusted_certificate /etc/ssl/certs/ca-certificates.crt;

init_by_lua_block
{
        cs = require "crowdsec"
        local ok, err = cs.init("./t/conf_t/17_live_and_tls_crowdsec_nginx_bouncer.conf", "crowdsec-nginx-bouncer/v1.0.8")
        if ok == nil then
                ngx.log(ngx.ERR, "[Crowdsec] " .. err)
                error()
        end
        ngx.log(ngx.ALERT, "[Crowdsec] Initialisation done")
}

access_by_lua_block {
        local cs = require "crowdsec"
        cs.Allow(ngx.var.remote_addr)
}

server {
    listen 8081 ssl;
    ssl_certificate /tmp/ca-test/server-cert.pem;
    ssl_certificate_key /tmp/ca-test/server-key.pem;
    ssl_client_certificate /tmp/ca-test/rootCA.pem;
    ssl_verify_client on;

    location = /v1/decisions {
        content_by_lua_block {
            local args, err = ngx.req.get_uri_args()
            if args.ip == "1.1.1.1" then
               ngx.say('[{"duration":"1h00m00s","id":4091593,"origin":"CAPI","scenario":"crowdsecurity/vpatch-CVE-2024-4577","scope":"Ip","type":"ban","value":"1.1.1.1"}]')
            else
               ngx.say('[{}]')
            end
        }
    }
}

--- config

location = /t {
    set_real_ip_from 127.0.0.1;
    real_ip_header   X-Forwarded-For;
    real_ip_recursive on;
    content_by_lua_block {
        ngx.say(ngx.var.remote_addr)
    }
}

--- more_headers
X-Forwarded-For: 1.1.1.1
--- request
GET /t
--- error_code: 403